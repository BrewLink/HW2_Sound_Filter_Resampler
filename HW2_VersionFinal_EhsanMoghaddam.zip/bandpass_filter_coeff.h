//
//  bandpass_filter_coeff.h
//  readWavFile
//
//  Created by ehsan on 4/19/22.
//

#ifndef bandpass_filter_coeff_h
#define bandpass_filter_coeff_h

#include <stdio.h>

#define NUMBER_OF_COEFFS 91
extern double coeffs[NUMBER_OF_COEFFS];


#endif /* bandpass_filter_coeff_h */
